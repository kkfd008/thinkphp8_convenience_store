<?php
declare (strict_types=1);

namespace app\controller;

use app\BaseController;
use app\service\BarcodeService;
use app\service\GoodsCateService;
use app\service\PinyinService;
use think\facade\Db;
use think\facade\View;

class Goods extends BaseController
{
    protected $middleware = ['auth'];

    public function index()
    {
        $keyword    = $this->request->get('keyword', '');
        $cate       = $this->request->get('cate', '');
        $supplierId = intval($this->request->get('supplier_id', 0));
        $status     = $this->request->get('status', '');

        $cateService = new GoodsCateService();
        $cates = $cateService->getActiveCates();
        $cateOptions = $cateService->getCateSelectOptions($cates);

        // 供货商列表
        $suppliers = Db::name('supplier')->field('id, name')->where('status', 1)->select()->toArray();

        View::assign(array_merge($this->assignAdminUser(), [
            'menus'       => $this->getMenus(),
            'keyword'     => $keyword,
            'cate'        => $cate,
            'supplierId'  => $supplierId,
            'status'      => $status,
            'cateList'    => $cates,
            'cateOptions' => $cateOptions,
            'suppliers'   => $suppliers,
        ]));
        return View::fetch();
    }

    public function list()
    {
        $page       = intval($this->request->get('page', 1));
        $limit      = intval($this->request->get('limit', 20));
        $keyword    = $this->request->get('keyword', '');
        $cate       = $this->request->get('cate', '');
        $supplierId = intval($this->request->get('supplier_id', 0));
        $status     = $this->request->get('status', '');

        $query = Db::name('goods')->alias('g')
            ->leftJoin('supplier s', 'g.supplier_id = s.id')
            ->field('g.*, s.name as supplier_name');

        if ($keyword !== '') {
            $query->where(function ($q) use ($keyword) {
                $q->where('g.name', 'like', "%{$keyword}%")
                  ->whereOr('g.barcode', 'like', "%{$keyword}%")
                  ->whereOr('g.pinyin_code', 'like', "%{$keyword}%")
                  ->whereOr('g.cate', 'like', "%{$keyword}%");
            });
        }
        if ($cate === '_none_') {
            $query->where('g.cate', '');
        } elseif ($cate !== '') {
            $query->where('g.cate', $cate);
        }
        if ($supplierId > 0) {
            $query->where('g.supplier_id', $supplierId);
        }
        if ($status !== '') {
            $query->where('g.status', intval($status));
        }

        $count = $query->count();
        $list  = $query->order('g.id desc')->page($page, $limit)->select()->toArray();

        return json(['code' => 0, 'msg' => '', 'count' => $count, 'data' => $list]);
    }

    public function add()
    {
        $data = $this->request->post();
        $barcode = $data['barcode'] ?? '';

        $exist = Db::name('goods')->where('barcode', $barcode)->find();
        if ($exist) {
            return $this->jsonError('该条码已存在');
        }

        // 自动生成拼音码
        $name = $data['name'] ?? '';
        $pinyinService = new PinyinService();
        $pinyinCode = $pinyinService->generatePinyinCode($name);

        // 处理到期日期
        $expiryStr = $data['expiry_date'] ?? '';
        $expiryDate = null;
        if ($expiryStr !== '') {
            $expiryDate = strtotime($expiryStr);
            if ($expiryDate === false) $expiryDate = null;
        }

        Db::name('goods')->insert([
            'name'           => $name,
            'barcode'        => $barcode,
            'pinyin_code'    => $pinyinCode,
            'unit'           => $data['unit'] ?? '',
            'box_spec'       => intval($data['box_spec'] ?? 0),
            'purchase_price' => floatval($data['purchase_price'] ?? 0),
            'retail_price'   => floatval($data['retail_price'] ?? 0),
            'stock'          => intval($data['stock'] ?? 0),
            'stock_min'      => $data['stock_min'] !== '' ? intval($data['stock_min']) : null,
            'stock_max'      => $data['stock_max'] !== '' ? intval($data['stock_max']) : null,
            'expiry_date'    => $expiryDate,
            'location'       => $data['location'] ?? '',
            'cate'           => $data['cate'] ?? '',
            'supplier_id'    => intval($data['supplier_id'] ?? 0),
            'status'         => intval($data['status'] ?? 1),
            'create_time'    => time(),
        ]);
        return $this->jsonSuccess([], '新增成功');
    }

    public function edit()
    {
        $data = $this->request->post();
        $id   = intval($data['id'] ?? 0);
        if ($id <= 0) {
            return $this->jsonError('参数错误');
        }

        $goods = Db::name('goods')->where('id', $id)->find();
        if (!$goods) {
            return $this->jsonError('商品不存在');
        }

        $newBarcode = $data['barcode'] ?? $goods['barcode'];
        if ($newBarcode !== $goods['barcode']) {
            $linkedCount = Db::name('purchase_detail')->where('barcode', $goods['barcode'])->count()
                         + Db::name('order_detail')->where('barcode', $goods['barcode'])->count();
            if ($linkedCount > 0) {
                return $this->jsonError('该商品已关联进货/订单，不可修改条码');
            }
            $exist = Db::name('goods')->where('barcode', $newBarcode)->where('id', '<>', $id)->find();
            if ($exist) {
                return $this->jsonError('该条码已被其他商品使用');
            }
        }

        // 名称变更时重新生成拼音码
        $name = $data['name'] ?? '';
        $pinyinService = new PinyinService();
        $pinyinCode = $pinyinService->generatePinyinCode($name);

        // 处理到期日期
        $expiryStr = $data['expiry_date'] ?? '';
        $expiryDate = null;
        if ($expiryStr !== '') {
            $expiryDate = strtotime($expiryStr);
            if ($expiryDate === false) $expiryDate = null;
        }

        Db::name('goods')->where('id', $id)->update([
            'name'           => $name,
            'barcode'        => $newBarcode,
            'pinyin_code'    => $pinyinCode,
            'unit'           => $data['unit'] ?? '',
            'box_spec'       => intval($data['box_spec'] ?? 0),
            'purchase_price' => floatval($data['purchase_price'] ?? 0),
            'retail_price'   => floatval($data['retail_price'] ?? 0),
            'cate'           => $data['cate'] ?? '',
            'stock_min'      => $data['stock_min'] !== '' ? intval($data['stock_min']) : null,
            'stock_max'      => $data['stock_max'] !== '' ? intval($data['stock_max']) : null,
            'expiry_date'    => $expiryDate,
            'location'       => $data['location'] ?? '',
            'supplier_id'    => intval($data['supplier_id'] ?? 0),
            'status'         => intval($data['status'] ?? 1),
        ]);
        return $this->jsonSuccess([], '编辑成功');
    }

    public function delete()
    {
        $id = intval($this->request->post('id', 0));
        if ($id <= 0) {
            return $this->jsonError('参数错误');
        }

        $goods = Db::name('goods')->where('id', $id)->find();
        if (!$goods) {
            return $this->jsonError('商品不存在');
        }

        $linkedCount = Db::name('purchase_detail')->where('barcode', $goods['barcode'])->count()
                     + Db::name('order_detail')->where('barcode', $goods['barcode'])->count();
        if ($linkedCount > 0) {
            return $this->jsonError('该商品已关联进货/订单，禁止删除');
        }

        Db::name('goods')->where('id', $id)->delete();
        return $this->jsonSuccess([], '删除成功');
    }

    /**
     * 批量删除
     */
    public function batchDelete()
    {
        $idsStr = $this->request->post('ids', '');
        $idArr = array_map('intval', explode(',', $idsStr));
        $idArr = array_filter($idArr, function ($v) { return $v > 0; });

        if (empty($idArr)) {
            return $this->jsonError('请选择商品');
        }

        $goodsList = Db::name('goods')->whereIn('id', $idArr)->select()->toArray();
        $barcodes = array_column($goodsList, 'barcode');

        $linkedCount = Db::name('purchase_detail')->whereIn('barcode', $barcodes)->count()
                     + Db::name('order_detail')->whereIn('barcode', $barcodes)->count();
        if ($linkedCount > 0) {
            return $this->jsonError('选中商品中存在已关联进货/订单的商品，禁止批量删除');
        }

        Db::name('goods')->whereIn('id', $idArr)->delete();
        return $this->jsonSuccess([], '已删除 ' . count($idArr) . ' 个商品');
    }

    /**
     * 批量上下架
     */
    public function batchToggleStatus()
    {
        $idsStr = $this->request->post('ids', '');
        $status = intval($this->request->post('status', 1));
        $idArr = array_map('intval', explode(',', $idsStr));
        $idArr = array_filter($idArr, function ($v) { return $v > 0; });

        if (empty($idArr)) {
            return $this->jsonError('请选择商品');
        }

        Db::name('goods')->whereIn('id', $idArr)->update(['status' => $status]);
        $label = $status == 1 ? '上架' : '下架';
        return $this->jsonSuccess([], '已' . $label . ' ' . count($idArr) . ' 个商品');
    }

    public function genBarcode()
    {
        $barcodeService = new BarcodeService();
        do {
            $barcode = $barcodeService->generate();
            $exist = Db::name('goods')->where('barcode', $barcode)->find();
        } while ($exist);

        return $this->jsonSuccess(['barcode' => $barcode]);
    }

    public function checkBarcode()
    {
        $barcode = $this->request->post('barcode', '');
        $id      = intval($this->request->post('id', 0));
        $query = Db::name('goods')->where('barcode', $barcode);
        if ($id > 0) {
            $query->where('id', '<>', $id);
        }
        $exist = $query->find();
        return $this->jsonSuccess(['exist' => $exist ? true : false]);
    }

    public function cateList()
    {
        $cateList = Db::name('goods_cate')->order('id asc')->select()->toArray();

        View::assign(array_merge($this->assignAdminUser(), [
            'menus'    => $this->getMenus(),
            'cateList' => $cateList,
        ]));
        return View::fetch();
    }

    public function cateAdd()
    {
        $name = $this->request->post('name', '');
        if (empty($name)) {
            return $this->jsonError('分类名称不能为空');
        }
        $exist = Db::name('goods_cate')->where('name', $name)->find();
        if ($exist) {
            return $this->jsonError('该分类已存在');
        }
        Db::name('goods_cate')->insert(['name' => $name, 'status' => 1, 'create_time' => time()]);
        return $this->jsonSuccess([], '新增成功');
    }

    public function cateEdit()
    {
        $id   = intval($this->request->post('id', 0));
        $name = $this->request->post('name', '');
        if ($id <= 0) return $this->jsonError('参数错误');
        if (empty($name)) return $this->jsonError('分类名称不能为空');
        $exist = Db::name('goods_cate')->where('name', $name)->where('id', '<>', $id)->find();
        if ($exist) return $this->jsonError('该分类已存在');
        Db::name('goods_cate')->where('id', $id)->update(['name' => $name]);
        return $this->jsonSuccess([], '修改成功');
    }

    public function cateToggle()
    {
        $id     = intval($this->request->post('id', 0));
        $status = intval($this->request->post('status', 1));
        if ($id <= 0) return $this->jsonError('参数错误');
        Db::name('goods_cate')->where('id', $id)->update(['status' => $status]);
        return $this->jsonSuccess([], $status == 1 ? '已显示' : '已隐藏');
    }

    public function import()
    {
        $file = $this->request->file('file');
        if (!$file) {
            return $this->jsonError('请选择文件');
        }

        $ext = strtolower($file->getOriginalExtension());
        if (!in_array($ext, ['xls', 'xlsx'])) {
            return $this->jsonError('仅支持 Excel 文件');
        }

        $savePath = runtime_path() . 'import_' . time() . '.' . $ext;
        $file->move(dirname($savePath), basename($savePath));

        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader(ucfirst($ext) === 'Xls' ? 'Xls' : 'Xlsx');
        $spreadsheet = $reader->load($savePath);
        $rows = $spreadsheet->getActiveSheet()->toArray();

        unlink($savePath);
        array_shift($rows);

        $successCount = 0;
        $failList     = [];
        $existBarcodes = array_column(Db::name('goods')->field('barcode')->select()->toArray(), 'barcode');
        $importBarcodes = [];
        $pinyinService = new PinyinService();

        foreach ($rows as $i => $row) {
            $name   = trim($row[0] ?? '');
            $barcode = trim($row[1] ?? '');
            $unit    = trim($row[2] ?? '');
            $boxSpec       = intval($row[3] ?? 0);
            $purchasePrice = floatval($row[4] ?? 0);
            $retailPrice   = floatval($row[5] ?? 0);
            $stock         = intval($row[6] ?? 0);
            $cate          = trim($row[7] ?? '');
            $stockMin      = isset($row[8]) && $row[8] !== '' ? intval($row[8]) : null;
            $stockMax      = isset($row[9]) && $row[9] !== '' ? intval($row[9]) : null;
            $location      = trim($row[10] ?? '');
            $expiryStr     = trim($row[11] ?? '');
            $supplierName  = trim($row[12] ?? '');
            $pinyinCode    = $pinyinService->generatePinyinCode($name);

            if (empty($name) || empty($barcode)) {
                $failList[] = "第" . ($i + 2) . "行：商品名称和条码不能为空";
                continue;
            }
            if (in_array($barcode, $existBarcodes, true) || in_array($barcode, $importBarcodes, true)) {
                $failList[] = "第" . ($i + 2) . "行：条码 {$barcode} 重复";
                continue;
            }
            $importBarcodes[] = $barcode;

            // 查找供货商
            $supplierId = 0;
            if ($supplierName !== '') {
                $supplier = Db::name('supplier')->where('name', $supplierName)->find();
                $supplierId = $supplier ? $supplier['id'] : 0;
            }

            // 处理到期日期
            $expiryDate = null;
            if ($expiryStr !== '') {
                $ts = strtotime($expiryStr);
                if ($ts !== false) $expiryDate = $ts;
            }

            Db::name('goods')->insert([
                'name'           => $name,
                'barcode'        => $barcode,
                'pinyin_code'    => $pinyinCode,
                'unit'           => $unit,
                'box_spec'       => $boxSpec,
                'purchase_price' => $purchasePrice,
                'retail_price'   => $retailPrice,
                'stock'          => $stock,
                'cate'           => $cate,
                'stock_min'      => $stockMin,
                'stock_max'      => $stockMax,
                'location'       => $location,
                'expiry_date'    => $expiryDate,
                'supplier_id'    => $supplierId,
                'create_time'    => time(),
            ]);
            $successCount++;
        }

        return $this->jsonSuccess([
            'success' => $successCount,
            'fail'    => count($failList),
            'details' => $failList,
        ], "导入完成：成功 {$successCount} 条，失败 " . count($failList) . " 条");
    }

    public function batchCate()
    {
        $ids  = json_decode($this->request->post('ids', '[]'), true);
        $cate = $this->request->post('cate', '');

        if (empty($ids)) return $this->jsonError('请选择商品');
        if ($cate === '') return $this->jsonError('请选择分类');

        Db::name('goods')->where('id', 'in', $ids)->update(['cate' => $cate]);
        return $this->jsonSuccess([], "已将 " . count($ids) . " 个商品分类修改为「{$cate}」");
    }

    public function downloadTemplate()
    {
        $headers = ['商品名称', '商品条码', '单位', '箱规', '进货价', '零售价', '库存数量', '商品分类', '最小库存', '最大库存', '库位', '到期日期', '供货商'];
        $this->downloadExcel($headers, [], '商品导入模板');
    }

    public function export()
    {
        $list = Db::name('goods')->alias('g')
            ->leftJoin('supplier s', 'g.supplier_id = s.id')
            ->field('g.*, s.name as supplier_name')
            ->select()->toArray();

        $headers = ['ID', '名称', '条码', '拼音码', '单位', '箱规', '进货价', '零售价', '库存', '最小库存', '最大库存', '分类', '库位', '到期日期', '供货商', '状态', '创建时间'];
        $data = [];
        foreach ($list as $row) {
            $data[] = [
                $row['id'], $row['name'], $row['barcode'], $row['pinyin_code'] ?? '',
                $row['unit'] ?? '', $row['box_spec'] ?? 0,
                $row['purchase_price'], $row['retail_price'], $row['stock'],
                $row['stock_min'], $row['stock_max'], $row['cate'],
                $row['location'] ?? '-',
                $row['expiry_date'] ? date('Y-m-d', $row['expiry_date']) : '-',
                $row['supplier_name'] ?? '-',
                $row['status'] == 1 ? '上架' : '下架',
                date('Y-m-d H:i:s', $row['create_time']),
            ];
        }
        return $this->downloadExcel($headers, $data, '商品列表');
    }

}